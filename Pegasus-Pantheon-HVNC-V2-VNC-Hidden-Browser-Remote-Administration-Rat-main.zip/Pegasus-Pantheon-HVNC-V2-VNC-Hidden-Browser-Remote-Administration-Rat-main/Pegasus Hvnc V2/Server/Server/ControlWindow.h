#include "Common.h"

BOOL CW_Register(WNDPROC lpfnWndProc);
HWND CW_Create(DWORD uhid, DWORD width, DWORD height);